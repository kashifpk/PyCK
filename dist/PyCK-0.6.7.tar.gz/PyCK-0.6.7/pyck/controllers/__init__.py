from crud_controller import CRUDController, add_crud_handler

__all__ = ['CRUDController', 'add_crud_handler']
