from pyck.forms import Form
import os


def test_pyck_lib_get_models_1():
    pass
    