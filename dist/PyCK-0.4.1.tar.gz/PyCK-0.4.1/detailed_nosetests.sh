#!/bin/sh
nosetests --nocapture -v --with-doctest
