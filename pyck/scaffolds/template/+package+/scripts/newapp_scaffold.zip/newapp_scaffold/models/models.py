from sqlalchemy import (
    Column,
    Integer,
    Unicode,
    )

from . import DBSession, Base

#class MyModel(Base):
#    __tablename__ = 'my_model'
#    id = Column(Integer, primary_key=True)
#    title = Column(Unicode(200), unique=True)
#
#    def __init__(self, title, content):
#        self.title = title

