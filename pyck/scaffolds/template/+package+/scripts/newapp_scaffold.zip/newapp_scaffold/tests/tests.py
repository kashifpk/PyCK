import unittest
import transaction

from pyramid import testing

from ..models import db


class TestMyView(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_it(self):
        pass
